[
  {
    "id": "1",
    "name": "Baby Spinach",
    "price": 0.60,
    "unit": "lb",
    "image": "https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=400",
    "category": "Fruits & Vegetables"
  },
  {
    "id": "2",
    "name": "Brussels Sprout",
    "price": 3.00,
    "unit": "lb",
    "image": "https://images.unsplash.com/photo-1632773683726-9c40b2a0b1d2?w-400",
    "category": "Fruits & Vegetables"
  },
  {
    "id": "3",
    "name": "Raspberries",
    "price": 3.00,
    "unit": "pint",
    "image": "https://images.unsplash.com/photo-1577069861033-55d04cec4ef5?w=400",
    "category": "Fruits & Vegetables"
  },
  {
    "id": "4",
    "name": "Celery Stick",
    "price": 6.00,
    "unit": "bunch",
    "image": "https://images.unsplash.com/photo-1600093463592-8e36ae95ef56?w=400",
    "category": "Fruits & Vegetables"
  },
  {
    "id": "5",
    "name": "Clementines",
    "price": 2.50,
    "unit": "lb",
    "image": "https://images.unsplash.com/photo-1596979578708-3e7c8b71c8d7?w=400",
    "category": "Fruits & Vegetables"
  },
  {
    "id": "6",
    "name": "Sweet Corn",
    "price": 4.00,
    "unit": "each",
    "image": "https://images.unsplash.com/photo-1576485375211-d04df4e44e9a?w=400",
    "category": "Fruits & Vegetables"
  },
  {
    "id": "7",
    "name": "Cucumber",
    "price": 2.50,
    "unit": "each",
    "image": "https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?w=400",
    "category": "Fruits & Vegetables"
  }
]